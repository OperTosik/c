#include "head.h"
#include "test.cpp"

int main() {
    test();
    return 0;
}