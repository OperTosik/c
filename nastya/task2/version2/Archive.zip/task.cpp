#include "head.h"

// class CVectElem
// Конструктор по умолчанию
CVectElem::CVectElem(): x(0.), y(0.) {}

// Конструктор с параметрами
CVectElem::CVectElem(double _x, double _y): x(_x), y(_y) {}

// Оператор сложения для CVectElem
CVectElem CVectElem::operator+(const CVectElem& other) const {
    double _x, _y;
    _x = x + other.x;
    _y = y + other.y;
    return CVectElem(_x, _y);
}

// Функция получения x текущего объект класса
double CVectElem::getX() const {
    return this->x;
}

// Функция получения y текущего объект класса
double CVectElem::getY() const {
    return this->y;
}





//class CVect
// Конструктор по умолчанию
CVect::CVect(): size(0), lenght(0), arr(nullptr) {}    //Пустой вектор

// Конструктор с параметрами
CVect::CVect(const CVectElem* other, size_t otherLenght, size_t otherSize) {
    arr = new CVectElem[otherSize];
    lenght = otherLenght;
    size = otherLenght;
    for (size_t i = 0; i < lenght; ++i) {
        arr[i] = other[i];
    }
}

//Конструктор копирования
CVect::CVect(const CVect& other) {
    lenght = other.getLenght();
    size = other.size;
    arr = new CVectElem[size];
    for (size_t i = 0; i < lenght; ++i) {
        arr[i] = other.arr[i];
    }
}

//Конструктор перемещения
CVect::CVect(CVect&& other) {
    lenght = other.getLenght();
    size = other.size;
    arr = other.arr;
    other.arr = nullptr;
}

//Деструктор
CVect::~CVect() {
    delete[] arr;
}

//Оператор присваивания
CVect CVect::operator=(const CVect& other) {
    delete[] arr;
    lenght = other.getLenght();
    size = other.size;
    arr = new CVectElem[size];
    for (size_t i = 0; i < lenght; ++i) {
        arr[i] = other.arr[i];
    }
    return *this;
}

//Оператор перемещения
CVect& CVect::operator=(CVect&& other) {
    delete[] arr;
    lenght = other.getLenght();
    size = other.size;
    arr = other.arr;
    other.arr = nullptr;
    return *this;
}

//Префиксныый инкремент
CVect& CVect::operator++() {
    CVect tmp = *this;
    delete[] arr;
    lenght++;
    size++;
    arr = new CVectElem[size];
    for (size_t i = 0; i < lenght - 1; ++i) {
        arr[i + 1] = tmp.arr[i];
    }
    arr[0] = arr[1];
    return *this;
}

//Постфиксный инкремент
CVect CVect::operator++(int) {
    CVect tmp = *this;
    delete[] arr;
    ++lenght;
    ++size;
    arr = new CVectElem[size];
    for (size_t i = 0; i < lenght - 1; i++) {
        arr[i] = tmp.arr[i];
    }
    arr[lenght - 1] = arr[lenght - 2];
    return *this;
}

//Префиксный декремент
CVect& CVect::operator--() {
    --lenght;
    for (size_t i = 0; i < lenght; ++i) {
        arr[i] = arr[i + 1];
    }
    arr[lenght] = CVectElem();
    return *this;
}

//Постфиксный декремент
CVect CVect::operator--(int) {
    lenght--;
    this->arr[lenght] = CVectElem();
    return *this;

}

//Оператор сложения массива вектора с массивом углов
CVect CVect::operator+(const CAngl& other) const& {
    double x, y;
    CVect tmp = *this;
    int resLenght = (lenght < other.getLenght()) ? lenght : other.getLenght();
    int resSize = (size < other.getSize()) ? size : other.getSize();
    CVectElem* res = new CVectElem[lenght];

    for (size_t i = 0; i < lenght; ++i) {
        x = tmp.arr[i].getX() * cos(other.getAngle(i)) - tmp.arr[i].getY() * sin(other.getAngle(i));
        y = tmp.arr[i].getX() * sin(other.getAngle(i)) + tmp.arr[i].getY() * cos(other.getAngle(i));
        res[i] = CVectElem(x, y);
    }
    return CVect(res, resLenght, resSize);
}


//Оператор вычитания векторов
CAngl CVect::operator-(const CVect& other) const {
    int angLenght = (lenght < other.getLenght()) ? lenght : other.getLenght();
    int angSize = (size < other.getSize()) ? size : other.getSize();
    double angle[angLenght];
    double xx;
    double yy;
    double _x, _y;

    for (int i = 0; i < angLenght; ++i) {
        if(other.arr[i].getX() < 0 && other.arr[i].getY() > 0 || other.arr[i].getX() < 0 && other.arr[i].getY() < 0 ){
            _x = other.arr[i].getX() * cos(M_PI) - other.arr[i].getY() * sin(M_PI);
            _y = other.arr[i].getX() * sin(M_PI) + other.arr[i].getY() * cos(M_PI);
        // angle[i] = acos((arr[i].getX()*other.arr[i].getX() + arr[i].getY()*other.arr[i].getY()) / 
        //             (sqrt(arr[i].getX()*arr[i].getX() + arr[i].getY()*arr[i].getY()) *
        //             (sqrt(other.arr[i].getX()*other.arr[i].getX() + other.arr[i].getY()*other.arr[i].getY()))));
        // angle[i] = asin((arr[i].getX()*other.arr[i].getY() - arr[i].getY()*other.arr[i].getX()) / 
        //             ((sqrt(arr[i].getX()*arr[i].getX() + arr[i].getY()*arr[i].getY()) *
        //             (sqrt(other.arr[i].getX()*other.arr[i].getX() + other.arr[i].getY()*other.arr[i].getY())))));
   //angle[i]= atan2(arr[i].getY() -  other.arr[i].getY(), arr[i].getX() -  other.arr[i].getX());
            xx = _x*arr[i].getX() + _y*arr[i].getY(); 
            yy = -_x*arr[i].getY() + _y*arr[i].getX(); 
            angle[i] = atan2(yy, xx);
        } else {
            xx = arr[i].getX()*other.arr[i].getX() + arr[i].getY()*other.arr[i].getY(); 
            yy = -arr[i].getX()*other.arr[i].getY() + arr[i].getY()*other.arr[i].getX(); 
            angle[i] = atan2(yy, xx);
        }
    }


    return CAngl(angle, angLenght, angSize);
}

//Функция возвращающая длину
size_t CVect::getLenght() const {
    return lenght;
}

size_t CVect::getSize() const {
    return size;
}

//Функция обращения к элементу массива векторов
CVectElem CVect::getVect(int k) const {
    return arr[k];
}

//Оператор вставки для массива векторов
std::ostream& operator<<(std::ostream& os, const CVect& v) {
    os << "{\n";
    for (size_t i = 0; i < v.getLenght(); ++i) {
        os << "\t(" << v.arr[i].getX() << ", " << v.arr[i].getY() << ")\n";
    }
    os << "}";
	return os;
}





//class CAngl
//Конструктор по умолчанию
CAngl::CAngl(): lenght(0), angle(nullptr) {}

//Конструтор с параметрами
CAngl::CAngl(double* _angle, size_t _lenght, size_t _size) {
    angle = new double[_lenght];
    lenght = _lenght;
    size = _size;
    for (size_t i = 0; i < lenght; ++i) {
        angle[i] = _angle[i];
    }
}

//Конструктор копирования
CAngl::CAngl(const CAngl& other) {
    lenght = other.getLenght();
    size = other.size;
    angle = new double[lenght];
    for (size_t i = 0; i < lenght; ++i) {
        angle[i] = other.angle[i];
    }
}

//Конструктор перемещения
CAngl::CAngl(CAngl&& other) {
    lenght = other.getLenght();
    size = other.size;
    angle = other.angle;
    other.angle = nullptr;
}

//Деструктор
CAngl::~CAngl() {
    delete[] angle;
}

//Оператор присваивания
CAngl CAngl::operator=(const CAngl& other) {
    delete[] angle;
    lenght = other.getLenght();
    size = other.size;
    angle = new double[lenght];
    for (size_t i = 0; i < lenght; ++i) {
        angle[i] = other.angle[i];
    }
    return *this;
}

//Оператор перемещения
CAngl& CAngl::operator=(CAngl&& other) {
    delete[] angle;
    lenght = other.getLenght();
    size = other.size;
    angle = other.angle;
    other.angle = nullptr;
    return *this;
}

//Префиксный инкремент
CAngl& CAngl::operator++() {
    CAngl tmp = *this;
    delete[] angle;
    ++lenght;
    ++size;
    angle = new double[lenght];
    for (size_t i = 0; i < lenght - 1; ++i) {
        angle[i + 1] = tmp.angle[i];
    }
    angle[0] = angle[1];
    return *this;
}

//Постфиксынй инкремент
CAngl CAngl::operator++(int) {
    CAngl tmp = *this;
    delete[] angle;
    ++lenght;
    ++size;
    angle = new double[lenght];
    for (size_t i = 0; i < lenght - 1; ++i) {
        angle[i] = tmp.angle[i + 1];
    }
    angle[lenght - 2] = angle[lenght - 1];
    return *this;
}

//Префиксный декремент
CAngl& CAngl::operator--() {
    CAngl tmp = *this;
    --lenght;
    for (size_t i = 0; i < lenght; ++i) {
        angle[i] = tmp.angle[i + 1];
    }
    angle[lenght - 1] = 0.;
    return *this;
}

//Постфиксный декремент
CAngl CAngl::operator--(int) {
    --lenght;
    angle[lenght - 1] = 0.;
    return *this;
}

//Оператор сложения массива углов  массивом векторов
CVect&& CAngl::operator+(CVect&& other) const& {
    double x, y;
    CAngl tmp = *this;
    int resLenght = (lenght < other.getLenght()) ? lenght : other.getLenght();
    int resSize = (size < other.getSize()) ? size : other.getSize();
    CVectElem* res = new CVectElem[lenght];

    for (size_t i = 0; i < lenght; ++i) {
        x = other.getVect(i).getX() * cos(tmp.getAngle(i)) - other.getVect(i).getY() * sin(tmp.getAngle(i));
        y = other.getVect(i).getX() * sin(tmp.getAngle(i)) + other.getVect(i).getY() * cos(tmp.getAngle(i));
        res[i] = CVectElem(x, y);
    }
    other = CVect(res, resLenght, resSize);
    return const_cast<CVect&&>(other);
}

//Функция возвращающая длину массива углов
size_t CAngl::getLenght() const {
    return lenght;
}

size_t CAngl::getSize() const {
    return size;
}

//Функция обращения к элементу массива углов
double CAngl::getAngle(int k) const {
    return angle[k];
}

//Оператор вставки для массива углов
std::ostream& operator<<(std::ostream& os, const CAngl& a) {
    os << "{\n";
    for (size_t i = 0; i < a.getLenght(); ++i) {
        os << "\t" << a.angle[i] << ",\n";
    }
    os << "}";
	return os;
}