#include "head.h"
#include "test.h"

int main() {
    CVectElem tmp[]={CVectElem(1,0),CVectElem(0,1)}; 
    CVect v(tmp,2, 2) ,w(tmp+1, 1, 1);
    std::cout << "v = " << v << "w = " << w << std::endl;
    std::cout << "v-- = " << (v-- ) << std::endl;
    // std::cout << "--v = " << (--v ) << std::endl;
    std::cout << "v=" << v << std::endl;;
    v+(v-w); // = v
    std::cout << "v=" << v << std::endl;;
    // return 0;


    std::cout << "Первый тест" << std::endl;
    test1();
    std::cout << "\n\n" << std::endl;

    std::cout << "Второй тест" << std::endl;
    test2();
    return 0;
}