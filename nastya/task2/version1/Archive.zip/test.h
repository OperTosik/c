#include "head.h"
#include <cstdlib>
#include <ctime>

// void getArray(CVect &arr);
// void getArray(CAngl &arr);
// void unaryOperatorMinus(CAngl& arr);
void test1();
void test2();
